E'S AI — CANVA PAGES + RENDER BACKEND

This project serves your existing E's AI chat page from Render and provides a private
server-side AI endpoint. Embed the Render URL into Canva Pages so the chat appears
inside the Canva page (rather than opening a separate chat tab).

WHAT IT DOES
- Keeps the original E's AI design and chat UI.
- Uses OpenAI first, Groq automatically as backup.
- API keys are server-side Render environment secrets, never put in browser code.
- Supports text and image attachments with the OpenAI model.
- Includes a basic per-IP rate limit (20 messages/minute).

IMPORTANT
- Rotate any API keys you previously pasted into chat. Do not reuse exposed keys.
- Add NEW keys only in Render Dashboard > your service > Environment.
- OpenAI usage is billed by OpenAI; Groq usage follows Groq's current plan/limits.
- Render's free web service can sleep after inactivity and take a little time to wake.
- This public demo endpoint has basic rate limiting, not user login. Anyone who can
  access the embedded chat may use your configured API quota. Do not publish it widely
  unless you are comfortable with that, or add authentication before launch.

DEPLOY (NO LOCAL NODE.JS NEEDED)
1. Download and unzip this folder.
2. Create a GitHub account if needed: https://github.com
3. Create a new repository, e.g. es-ai-canva. Upload all files/folders from this
   project (including public/index.html) to the repository.
4. Open https://render.com and sign in using GitHub.
5. Choose New + > Blueprint, select the repository, and deploy the render.yaml.
   Alternatively choose New + > Web Service and use:
     Runtime: Node
     Build command: (leave blank)
     Start command: node server.js
6. In Render > service > Environment, add:
     OPENAI_API_KEY = your NEW OpenAI key
     GROQ_API_KEY = your NEW Groq key
   Keep the OPENAI_MODEL and GROQ_MODEL values from render.yaml unless you know
   you want to change them. Save; Render will redeploy.
7. Open the Render service URL, e.g. https://your-service.onrender.com.
   Wait for it to load and test a chat. /api/health should show the backend status.
8. In Canva, edit your Canva Website/Page. Choose Apps > Embed (or Embed a website),
   paste the Render service URL, and resize the embed to fit your design. Publish.
   If Canva does not allow an interactive full-page embed in your selected page layout,
   use Canva's website embed element or a button linking to the Render URL.

NO LOCAL NODE INSTALLATION
Render runs Node remotely. You only use GitHub and Render in your browser.

NOTES
- The chat page keeps conversation history in that visitor's browser local storage.
- The Render server does not store chat history.
- This package has not been live-tested against your API accounts. Test after adding
  the new secrets; verify API access and billing on the provider dashboards.
