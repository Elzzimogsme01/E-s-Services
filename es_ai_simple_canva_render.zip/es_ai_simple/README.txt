E'S AI — SIMPLE RENDER + CANVA SETUP

This version uses ONE secret: OPENAI_API_KEY. GROQ_API_KEY is optional and not needed.

IMPORTANT: Put these files DIRECTLY in the ROOT of your GitHub repository:
- package.json
- server.js
- public/index.html

Do not put them inside another folder.

RENDER SETTINGS (create a NEW Web Service):
- Runtime: Node
- Root Directory: leave EMPTY
- Build Command: npm install
- Start Command: node server.js
- Instance: Free

Environment Variables:
- Key: OPENAI_API_KEY
- Value: your NEW OpenAI API key

You do not need GROQ_API_KEY.

After deployment succeeds, open the Render URL. The chat page is served directly by Render.
To put it in Canva: open Canva website editor > Apps > search Embed > paste the Render URL > Add to design. Resize the embedded frame, then publish the Canva website.

The API key stays in Render's Environment settings, not in the HTML. Never paste it into Canva or GitHub.
