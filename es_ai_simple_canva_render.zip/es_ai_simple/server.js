const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const PORT = Number(process.env.PORT || 3000);
const OPENAI_KEY = process.env.OPENAI_API_KEY;
const GROQ_KEY = process.env.GROQ_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";
const GROQ_MODEL = process.env.GROQ_MODEL || "openai/gpt-oss-120b";
const PUBLIC_DIR = path.join(__dirname, "public");
const buckets = new Map();

function send(res, status, body, type = "application/json; charset=utf-8") {
  res.writeHead(status, {
    "Content-Type": type,
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Cache-Control": "no-store"
  });
  res.end(typeof body === "string" ? body : JSON.stringify(body));
}
function rateLimit(req) {
  const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "unknown").split(",")[0].trim();
  const now = Date.now();
  let b = buckets.get(ip);
  if (!b || now - b.start > 60_000) b = { start: now, count: 0 };
  b.count++;
  buckets.set(ip, b);
  if (buckets.size > 10000) {
    for (const [k, v] of buckets) if (now - v.start > 60_000) buckets.delete(k);
  }
  return b.count <= 20;
}
async function readJson(req) {
  let raw = "";
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > 8 * 1024 * 1024) throw new Error("Request too large (8 MB maximum).");
  }
  return JSON.parse(raw || "{}");
}
async function askProvider(url, key, model, messages) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model, messages, temperature: 0.7, stream: false })
  });
  const raw = await response.text();
  let data;
  try { data = JSON.parse(raw); } catch { data = {}; }
  if (!response.ok) {
    const detail = data?.error?.message || data?.error || `Provider returned HTTP ${response.status}`;
    throw new Error(String(detail).slice(0, 500));
  }
  const content = data?.choices?.[0]?.message?.content;
  if (typeof content === "string" && content.trim()) return content;
  if (Array.isArray(content)) {
    const text = content.map(x => x.text || "").join("");
    if (text.trim()) return text;
  }
  throw new Error("Provider returned an empty response.");
}
function streamText(res, text, provider) {
  res.writeHead(200, {
    "Content-Type": "text/event-stream; charset=utf-8",
    "Cache-Control": "no-cache, no-transform",
    "Connection": "keep-alive",
    "Access-Control-Allow-Origin": "*",
    "X-AI-Provider": provider
  });
  // Stream text in small pieces so the existing chat UI can render progressively.
  const chunks = text.match(/[\s\S]{1,24}/g) || [text];
  let i = 0;
  const pump = () => {
    if (res.destroyed) return;
    if (i >= chunks.length) { res.write("data: [DONE]\n\n"); return res.end(); }
    const piece = JSON.stringify({ choices: [{ delta: { content: chunks[i++] } }] });
    res.write(`data: ${piece}\n\n`);
    setTimeout(pump, 8);
  };
  pump();
}
const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return send(res, 204, "");
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  if (req.method === "GET" && url.pathname === "/api/health") {
    return send(res, 200, {
      ok: Boolean(OPENAI_KEY || GROQ_KEY),
      provider: OPENAI_KEY ? "Connected · OpenAI + Groq backup" : (GROQ_KEY ? "Connected · Groq" : "Backend online · API keys not configured")
    });
  }
  if (req.method === "POST" && url.pathname === "/api/chat") {
    if (!rateLimit(req)) return send(res, 429, { error: "Too many messages from this connection. Please wait a minute and try again." });
    let body;
    try { body = await readJson(req); } catch (e) { return send(res, 400, { error: e.message || "Invalid request." }); }
    if (!Array.isArray(body.messages) || body.messages.length < 1 || body.messages.length > 40) {
      return send(res, 400, { error: "A valid chat history is required (up to 40 messages)." });
    }
    const messages = body.messages.map(m => {
      if (!m || !["system", "user", "assistant"].includes(m.role)) throw new Error("Invalid message role.");
      return { role: m.role, content: m.content };
    });
    try {
      let reply, used;
      const failures = [];
      if (OPENAI_KEY) {
        try {
          reply = await askProvider("https://api.openai.com/v1/chat/completions", OPENAI_KEY, OPENAI_MODEL, messages);
          used = "OpenAI";
        } catch (e) { failures.push(`OpenAI: ${e.message}`); }
      }
      if (!reply && GROQ_KEY) {
        try {
          reply = await askProvider("https://api.groq.com/openai/v1/chat/completions", GROQ_KEY, GROQ_MODEL, messages);
          used = "Groq backup";
        } catch (e) { failures.push(`Groq: ${e.message}`); }
      }
      if (!reply) {
        const msg = (!OPENAI_KEY && !GROQ_KEY)
          ? "The backend is online, but its API keys have not been added in Render."
          : failures.join(" | ") || "No AI provider is configured.";
        return send(res, 502, { error: msg });
      }
      return streamText(res, reply, used);
    } catch (e) {
      return send(res, 400, { error: e.message || "Could not process this message." });
    }
  }
  if (req.method === "GET" && (url.pathname === "/" || url.pathname === "/index.html")) {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-cache" });
    return fs.createReadStream(path.join(PUBLIC_DIR, "index.html")).pipe(res);
  }
  if (req.method === "GET" && url.pathname === "/favicon.ico") return send(res, 204, "");
  return send(res, 404, { error: "Not found." });
});
server.listen(PORT, "0.0.0.0", () => console.log(`E's AI listening on ${PORT}`));
